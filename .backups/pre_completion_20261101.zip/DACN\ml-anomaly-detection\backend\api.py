"""FastAPI endpoint for CSV anomaly detection."""

from __future__ import annotations

from io import BytesIO

import pandas as pd
from fastapi import FastAPI, File, HTTPException, UploadFile

from src.data_prep import (
    compute_robust_z_scores,
    database_metric_columns,
    load_timeseries,
)
from src.models import build_feature_matrix, evaluate_predictions, fit_models

app = FastAPI(title="ML Anomaly Detection API", version="1.0.0")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/detect")
async def detect(
    file: UploadFile = File(...),
    timestamp_col: str = "timestamp",
    value_col: str | None = None,
    contamination: float = 0.01,
) -> dict:
    """Analyze a CSV and return anomaly points from three models."""
    try:
        frame = load_timeseries(BytesIO(await file.read()), timestamp_col, value_col)
        if len(frame) < 10:
            raise ValueError("CSV must contain at least 10 valid rows")
        split = max(2, int(len(frame) * 0.7))
        value_name = value_col or database_metric_columns(frame)[0]
        if value_name == "is_anomaly":
            raise ValueError("value_col must be a database activity metric")
        features = build_feature_matrix(frame, value_name, timestamp_col)
        results = fit_models(features.iloc[:split], features.iloc[split:], contamination)
        payload = {}
        metrics = {}
        if "is_anomaly" in frame.columns:
            truth = frame["is_anomaly"].iloc[split:]
            mad_frame = compute_robust_z_scores(frame.iloc[split:], value_name)
            metrics["mad"] = evaluate_predictions(truth, mad_frame["baseline"])
        for name, result in results.items():
            rows = frame.iloc[split:].copy()
            rows["prediction"] = result.predictions
            rows["score"] = result.scores
            if "is_anomaly" in rows.columns:
                metrics[name] = evaluate_predictions(rows["is_anomaly"], result.predictions)
            anomalies = rows[rows["prediction"] == -1].copy()
            anomalies[timestamp_col] = anomalies[timestamp_col].dt.strftime("%Y-%m-%dT%H:%M:%S")
            payload[name] = anomalies.to_dict(orient="records")
        return {"rows": len(frame), "metrics": metrics, "models": payload}
    except (ValueError, StopIteration, pd.errors.ParserError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
