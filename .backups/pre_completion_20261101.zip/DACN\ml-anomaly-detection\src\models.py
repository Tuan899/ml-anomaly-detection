"""Anomaly models, hyperparameter search and imbalanced metrics."""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from collections.abc import Sequence

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import f1_score, precision_score, recall_score
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM


@dataclass(frozen=True)
class ModelResult:
    name: str
    predictions: np.ndarray
    scores: np.ndarray


def _validate_features(features: pd.DataFrame | np.ndarray) -> np.ndarray:
    values = features.to_numpy() if isinstance(features, pd.DataFrame) else np.asarray(features)
    if values.ndim == 1:
        values = values.reshape(-1, 1)
    if values.ndim != 2 or len(values) == 0:
        raise ValueError("Features must be a non-empty 2D array")
    if not np.isfinite(values).all():
        raise ValueError("Features must contain only finite numbers")
    return values


def _model_result(name: str, model, features: np.ndarray) -> ModelResult:
    predictions = model.predict(features).astype(int)
    scores = model.decision_function(features)
    return ModelResult(name, predictions, np.asarray(scores, dtype=float))


def fit_models(
    train_features: pd.DataFrame | np.ndarray,
    test_features: pd.DataFrame | np.ndarray,
    contamination: float = 0.01,
    random_state: int = 42,
) -> dict[str, ModelResult]:
    """Fit Isolation Forest, LOF and One-Class SVM on train data."""
    if not 0 < contamination <= 0.5:
        raise ValueError("contamination must be in the interval (0, 0.5]")
    train = _validate_features(train_features)
    test = _validate_features(test_features)
    models = {
        "isolation_forest": IsolationForest(
            contamination=contamination, random_state=random_state
        ),
        "lof": LocalOutlierFactor(
            contamination=contamination, novelty=True, n_neighbors=min(20, max(2, len(train) - 1))
        ),
        "one_class_svm": OneClassSVM(nu=contamination, kernel="rbf", gamma="scale"),
    }
    results = {}
    for name, model in models.items():
        model.fit(train)
        results[name] = _model_result(name, model, test)
    return results


def evaluate_predictions(y_true: pd.Series | np.ndarray, predictions: pd.Series | np.ndarray) -> dict[str, float]:
    """Compute precision, recall and F1 for anomaly label -1."""
    truth = np.asarray(y_true)
    predicted = np.asarray(predictions)
    if len(truth) != len(predicted):
        raise ValueError("y_true and predictions must have equal length")
    return {
        "precision": float(precision_score(truth, predicted, pos_label=-1, zero_division=0)),
        "recall": float(recall_score(truth, predicted, pos_label=-1, zero_division=0)),
        "f1": float(f1_score(truth, predicted, pos_label=-1, zero_division=0)),
    }


def tune_model(
    model_name: str,
    features: pd.DataFrame | np.ndarray,
    labels: pd.Series | np.ndarray,
    param_grid: dict[str, list] | None = None,
    contamination: float = 0.01,
    random_state: int = 42,
) -> dict:
    """Select parameters using F1 on supplied labeled validation data."""
    X = _validate_features(features)
    y = np.asarray(labels)
    if len(X) != len(y):
        raise ValueError("features and labels must have equal length")
    defaults = {
        "isolation_forest": {"n_estimators": [100, 200], "max_samples": ["auto", 0.8]},
        "lof": {"n_neighbors": [10, 20, 35], "leaf_size": [20, 30]},
    }
    grid = param_grid or defaults.get(model_name)
    if grid is None:
        raise ValueError("Tuning supports only isolation_forest and lof")
    keys = list(grid)
    best: dict | None = None
    for values in product(*(grid[key] for key in keys)):
        params = dict(zip(keys, values))
        if model_name == "isolation_forest":
            model = IsolationForest(contamination=contamination, random_state=random_state, **params)
        else:
            model = LocalOutlierFactor(
                contamination=contamination, novelty=True, **params
            )
        model.fit(X)
        score = evaluate_predictions(y, model.predict(X))["f1"]
        if best is None or score > best["f1"]:
            best = {"model": model_name, "params": params, "f1": score}
    assert best is not None
    return best


def build_feature_matrix(
    frame: pd.DataFrame,
    value_col: str | Sequence[str],
    timestamp_col: str = "timestamp",
) -> pd.DataFrame:
    """Build a time-series feature matrix with calendar features."""
    from .data_prep import add_time_features

    enriched = add_time_features(frame, timestamp_col)
    value_columns = [value_col] if isinstance(value_col, str) else list(value_col)
    missing = [column for column in value_columns if column not in enriched.columns]
    if missing:
        raise ValueError(f"Missing metric columns: {', '.join(missing)}")
    columns = value_columns + [
        "hour_sin",
        "hour_cos",
        "dow_sin",
        "dow_cos",
        "is_weekend",
    ]
    return enriched[columns].astype(float)
