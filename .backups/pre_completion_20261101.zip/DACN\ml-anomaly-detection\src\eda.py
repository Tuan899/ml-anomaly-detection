"""Interactive EDA plots for trend and seasonality."""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from .data_prep import add_time_features


def trend_figure(frame: pd.DataFrame, value_col: str, timestamp_col: str = "timestamp") -> go.Figure:
    """Create an interactive time-series trend chart."""
    data = add_time_features(frame, timestamp_col)
    return px.line(data, x=timestamp_col, y=value_col, title=f"Trend - {value_col}")


def seasonality_figure(frame: pd.DataFrame, value_col: str, timestamp_col: str = "timestamp") -> go.Figure:
    """Create hourly and weekday seasonality charts."""
    data = add_time_features(frame, timestamp_col)
    hourly = data.groupby("hour", as_index=False)[value_col].mean()
    weekday = data.groupby("day_of_week", as_index=False)[value_col].mean()
    figure = make_subplots(rows=1, cols=2, subplot_titles=("Theo giờ", "Theo ngày trong tuần"))
    figure.add_trace(go.Scatter(x=hourly["hour"], y=hourly[value_col], mode="lines+markers"), row=1, col=1)
    figure.add_trace(go.Bar(x=weekday["day_of_week"], y=weekday[value_col]), row=1, col=2)
    figure.update_layout(title="Seasonality", xaxis_title="Giờ", xaxis2_title="Ngày trong tuần")
    return figure
