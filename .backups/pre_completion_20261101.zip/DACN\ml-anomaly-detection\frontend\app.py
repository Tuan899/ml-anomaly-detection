"""Streamlit dashboard for interactive anomaly analysis."""

from __future__ import annotations

import json

import plotly.graph_objects as go
import streamlit as st

from src.data_prep import database_metric_columns, load_timeseries
from src.eda import seasonality_figure, trend_figure
from src.models import build_feature_matrix, evaluate_predictions, fit_models

st.set_page_config(page_title="NAB Anomaly Detection", page_icon="📈", layout="wide")

with st.sidebar:
    st.header("Cấu hình phân tích")
    dark_mode = st.toggle("Giao diện tối", value=True)
    timestamp_col = st.text_input("Cột timestamp", "timestamp")
    contamination = st.slider(
        "Tỷ lệ bất thường", min_value=0.001, max_value=0.1, value=0.01, step=0.001,
        help="Tỷ lệ càng cao thì mô hình càng đánh dấu nhiều điểm là bất thường.",
    )

if dark_mode:
    st.markdown(
        """
        <style>
        .stApp { background: #0f172a; }
        [data-testid="stMetric"] { background: #1e293b; border-radius: 12px; padding: 14px; }
        </style>
        """,
        unsafe_allow_html=True,
    )
else:
    st.markdown(
        """
        <style>
        [data-testid="stMetric"] { background: #f8fafc; border-radius: 12px; padding: 14px; }
        </style>
        """,
        unsafe_allow_html=True,
    )

st.title("📈 Phát hiện bất thường CPU - NAB")
st.caption("Phân tích xu hướng, mùa vụ và so sánh các mô hình học máy không giám sát.")
uploaded = st.file_uploader("Tải CSV lên để bắt đầu", type=["csv"])

if uploaded:
    try:
        frame = load_timeseries(uploaded, timestamp_col)
    except ValueError as exc:
        st.error(str(exc))
        st.stop()
    numeric_columns = database_metric_columns(frame)
    if not numeric_columns:
        st.error("CSV phải có ít nhất một cột giá trị dạng số.")
        st.stop()
    value_col = st.sidebar.selectbox("Cột giá trị", numeric_columns)
    if len(frame) < 10:
        st.error("CSV phải có ít nhất 10 dòng dữ liệu.")
        st.stop()

    split = max(2, int(len(frame) * 0.7))
    features = build_feature_matrix(frame, value_col, timestamp_col)
    results = fit_models(features.iloc[:split], features.iloc[split:], contamination)

    all_predictions = {name: result.predictions for name, result in results.items()}
    anomaly_counts = {name: int((predictions == -1).sum()) for name, predictions in all_predictions.items()}
    total_anomalies = max(anomaly_counts.values(), default=0)
    summary = st.container()
    with summary:
        st.subheader("Tổng quan dữ liệu")
        cards = st.columns(4)
        cards[0].metric("Tổng số điểm", f"{len(frame):,}")
        cards[1].metric("Giá trị trung bình", f"{frame[value_col].mean():.4f}")
        cards[2].metric("Giá trị lớn nhất", f"{frame[value_col].max():.4f}")
        cards[3].metric("Anomaly phát hiện", f"{total_anomalies:,}")

    st.subheader("Xu hướng dữ liệu")
    trend = trend_figure(frame, value_col, timestamp_col)
    trend.update_layout(template="plotly_dark" if dark_mode else "plotly_white", height=420)
    for name, result in results.items():
        anomaly_rows = frame.iloc[split:].loc[result.predictions == -1]
        trend.add_trace(
            go.Scatter(
                x=anomaly_rows[timestamp_col],
                y=anomaly_rows[value_col],
                mode="markers",
                name=f"{name.replace('_', ' ').title()} anomaly",
                marker={"size": 9, "symbol": "x"},
            )
        )
    st.plotly_chart(trend, use_container_width=True)

    eda_left, eda_right = st.columns(2)
    with eda_left:
        st.subheader("Mùa vụ theo thời gian")
        seasonality = seasonality_figure(frame, value_col, timestamp_col)
        seasonality.update_layout(
            template="plotly_dark" if dark_mode else "plotly_white", height=420
        )
        st.plotly_chart(seasonality, use_container_width=True)
    with eda_right:
        st.subheader("So sánh mô hình")
        comparison = go.Figure()
        for name, count in anomaly_counts.items():
            comparison.add_trace(
                go.Bar(name=name.replace("_", " ").title(), x=["Anomaly"], y=[count])
            )
        comparison.update_layout(
            barmode="group",
            template="plotly_dark" if dark_mode else "plotly_white",
            yaxis_title="Số điểm bất thường",
            height=420,
        )
        st.plotly_chart(comparison, use_container_width=True)

    if "is_anomaly" in frame.columns:
        st.subheader("Đánh giá mô hình")
        truth = frame["is_anomaly"].iloc[split:]
        metric_rows = [
            {"Mô hình": name.replace("_", " ").title(), **evaluate_predictions(truth, result.predictions)}
            for name, result in results.items()
        ]
        st.dataframe(metric_rows, use_container_width=True, hide_index=True)
    else:
        st.info("Thêm cột `is_anomaly` với nhãn 1/-1 để xem Precision, Recall và F1-score.")

    st.subheader("Chi tiết điểm bất thường")
    tabs = st.tabs([name.replace("_", " ").title() for name in results])
    for tab, (name, result) in zip(tabs, results.items()):
        with tab:
            anomalies = frame.iloc[split:].loc[result.predictions == -1].copy()
            anomalies["prediction"] = -1
            anomalies["score"] = result.scores[result.predictions == -1]
            st.metric("Số điểm bất thường", len(anomalies))
            st.dataframe(anomalies, use_container_width=True, hide_index=True)
            st.download_button(
                "Tải kết quả JSON",
                data=json.dumps(anomalies.to_dict(orient="records"), default=str, ensure_ascii=False),
                file_name=f"{name}_anomalies.json",
                mime="application/json",
                key=f"download-{name}",
            )
