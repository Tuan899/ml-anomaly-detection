"""Reusable NAB CPU anomaly-detection workflow."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .data_prep import add_nab_labels, compute_robust_z_scores, load_timeseries
from .models import evaluate_predictions, fit_models


def run_nab_analysis(
    source: str | Path,
    split_index: int = 3550,
    contamination: float | None = None,
) -> tuple[pd.DataFrame, dict[str, dict[str, float]]]:
    """Run MAD and three unsupervised models on the NAB CPU CSV."""
    frame = add_nab_labels(load_timeseries(source, value_col="value"))
    if not 1 < split_index < len(frame):
        raise ValueError("split_index must be between the first and last row")
    contamination = contamination or 1 / split_index
    mad = compute_robust_z_scores(frame)
    metrics = {"mad": evaluate_predictions(frame["is_anomaly"], mad["baseline"])}
    results = fit_models(
        frame[["value"]].iloc[:split_index],
        frame[["value"]].iloc[split_index:],
        contamination=contamination,
    )
    for name, result in results.items():
        metrics[name] = evaluate_predictions(
            frame["is_anomaly"].iloc[split_index:], result.predictions
        )
    return frame, metrics


if __name__ == "__main__":
    data_path = Path(__file__).parents[1] / "data" / "cpu_0.csv"
    _, analysis_metrics = run_nab_analysis(data_path)
    print(analysis_metrics)
