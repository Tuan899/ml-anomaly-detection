"""Time-series loading, NAB labeling and feature engineering helpers."""

from __future__ import annotations

from pathlib import Path
from urllib.request import urlretrieve

import pandas as pd
import numpy as np


NAB_DATASETS = {
    "ec2_cpu_utilization": (
        "https://raw.githubusercontent.com/numenta/NAB/master/data/"
        "realAWSCloudwatch/ec2_cpu_utilization_24ae8d.csv"
    ),
    "machine_temperature": (
        "https://raw.githubusercontent.com/numenta/NAB/master/data/"
        "realKnownCause/machine_temperature_system_failure.csv"
    ),
    "network_traffic": (
        "https://raw.githubusercontent.com/numenta/NAB/master/data/"
        "realTraffic/occupancy_t4013.csv"
    ),
}

NAB_ANOMALY_TIMESTAMPS = (
    "2014-02-26 22:05:00",
    "2014-02-27 17:15:00",
)


def load_timeseries(
    source: str | Path | object,
    timestamp_col: str = "timestamp",
    value_col: str | None = None,
) -> pd.DataFrame:
    """Load a CSV path, file-like object, or DataFrame and normalize its columns."""
    if isinstance(source, pd.DataFrame):
        frame = source.copy()
    else:
        frame = pd.read_csv(source)
    if timestamp_col not in frame.columns:
        raise ValueError(f"Missing timestamp column: {timestamp_col}")
    frame[timestamp_col] = pd.to_datetime(frame[timestamp_col], errors="coerce")
    if frame[timestamp_col].isna().any():
        raise ValueError(f"Column {timestamp_col} contains invalid timestamps")
    if value_col is None:
        candidates = [c for c in frame.columns if c != timestamp_col]
        numeric = [c for c in candidates if pd.api.types.is_numeric_dtype(frame[c])]
        if not numeric:
            raise ValueError("CSV must contain at least one numeric value column")
        value_col = numeric[0]
    if value_col not in frame.columns:
        raise ValueError(f"Missing value column: {value_col}")
    frame[value_col] = pd.to_numeric(frame[value_col], errors="coerce")
    frame = frame.dropna(subset=[timestamp_col, value_col]).sort_values(timestamp_col)
    return frame.reset_index(drop=True)


def database_metric_columns(frame: pd.DataFrame) -> list[str]:
    """Return numeric activity columns, excluding ground-truth labels."""
    excluded = {"is_anomaly", "anomaly", "label"}
    return [
        column
        for column in frame.columns
        if column not in excluded and pd.api.types.is_numeric_dtype(frame[column])
    ]


def add_nab_labels(
    frame: pd.DataFrame,
    timestamp_col: str = "timestamp",
    anomaly_timestamps: tuple[str, ...] = NAB_ANOMALY_TIMESTAMPS,
) -> pd.DataFrame:
    """Add NAB ground-truth labels using the timestamps from combined_labels.json."""
    if timestamp_col not in frame.columns:
        raise ValueError(f"Missing timestamp column: {timestamp_col}")
    result = frame.copy()
    timestamps = pd.to_datetime(result[timestamp_col], errors="raise")
    known_anomalies = pd.to_datetime(list(anomaly_timestamps))
    result["is_anomaly"] = 1
    result.loc[timestamps.isin(known_anomalies), "is_anomaly"] = -1
    return result


def compute_robust_z_scores(
    frame: pd.DataFrame,
    value_col: str = "value",
) -> pd.DataFrame:
    """Calculate robust z-scores and MAD baseline predictions."""
    from scipy.stats import median_abs_deviation

    if value_col not in frame.columns:
        raise ValueError(f"Missing value column: {value_col}")
    result = frame.copy()
    median = float(np.median(result[value_col]))
    mad = float(median_abs_deviation(result[value_col]))
    if mad == 0:
        raise ValueError("MAD is zero; robust z-scores cannot be calculated")
    result["z_score"] = 0.6745 * (result[value_col] - median) / mad
    result["baseline"] = np.where(result["z_score"].abs() >= 3.5, -1, 1)
    return result


def add_time_features(
    frame: pd.DataFrame,
    timestamp_col: str = "timestamp",
) -> pd.DataFrame:
    """Add cyclical and calendar features without changing the source frame."""
    if timestamp_col not in frame.columns:
        raise ValueError(f"Missing timestamp column: {timestamp_col}")
    result = frame.copy()
    timestamps = pd.to_datetime(result[timestamp_col], errors="raise")
    result["hour"] = timestamps.dt.hour
    result["day_of_week"] = timestamps.dt.dayofweek
    result["is_weekend"] = (timestamps.dt.dayofweek >= 5).astype(int)
    result["day_of_month"] = timestamps.dt.day
    result["month"] = timestamps.dt.month
    result["hour_sin"] = np.sin(2 * np.pi * result["hour"] / 24)
    result["hour_cos"] = np.cos(2 * np.pi * result["hour"] / 24)
    result["dow_sin"] = np.sin(2 * np.pi * result["day_of_week"] / 7)
    result["dow_cos"] = np.cos(2 * np.pi * result["day_of_week"] / 7)
    return result


def summarize_seasonality(
    frame: pd.DataFrame,
    value_col: str,
    timestamp_col: str = "timestamp",
) -> dict[str, pd.DataFrame]:
    """Return hourly, weekday and monthly aggregates for seasonality analysis."""
    enriched = add_time_features(frame, timestamp_col)
    return {
        "hourly": enriched.groupby("hour")[value_col].agg(["mean", "median", "std"]).reset_index(),
        "weekday": enriched.groupby("day_of_week")[value_col].agg(["mean", "median", "std"]).reset_index(),
        "monthly": enriched.groupby("month")[value_col].agg(["mean", "median", "std"]).reset_index(),
    }


def download_nab_dataset(name: str, output_dir: str | Path = "data") -> Path:
    """Download a named NAB example dataset and return its local path."""
    if name not in NAB_DATASETS:
        raise ValueError(f"Unknown NAB dataset {name!r}; choose from {sorted(NAB_DATASETS)}")
    target_dir = Path(output_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / f"{name}.csv"
    urlretrieve(NAB_DATASETS[name], target)
    return target
