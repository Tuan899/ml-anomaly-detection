# Nghiên cứu thuật toán phát hiện bất thường trong chuỗi thời gian

Project tái hiện nghiên cứu trên dữ liệu CPU của AWS EC2 thuộc Numenta Anomaly
Benchmark (NAB), bằng MAD, Isolation Forest, LOF và One-Class SVM.

## Cài đặt

```powershell
python -m pip install -r requirements.txt
```

## Chạy dashboard và API

```powershell
streamlit run frontend/app.py
uvicorn backend.api:app --reload
```

API `POST /detect` nhận multipart CSV với cột `timestamp` và một cột số (hoặc
truyền `value_col`), trả về danh sách điểm bất thường theo từng mô hình.

## Tải thêm dữ liệu NAB

Có thể tải các bộ mẫu bổ sung bằng:

```python
from src.data_prep import download_nab_dataset
download_nab_dataset("machine_temperature")
download_nab_dataset("network_traffic")
```

Các tên hợp lệ: `ec2_cpu_utilization`, `machine_temperature`,
`network_traffic`.

## Dữ liệu CPU dùng trong notebook

Các file [data/cpu_0.csv](./data/cpu_0.csv) đến
[data/cpu_5.csv](./data/cpu_5.csv) gồm cùng 4032 điểm đo CPU mỗi 5 phút.
Hai timestamp bất thường được lấy từ nhãn NAB:
`2014-02-26 22:05:00` và `2014-02-27 17:15:00`.

Nếu cần tải lại:

```python
from src.data_prep import download_nab_dataset
download_nab_dataset("ec2_cpu_utilization")
```

Notebook chính nằm tại [notebooks/exploratory.ipynb](./notebooks/exploratory.ipynb).

## Thành phần chính

- `src/data_prep.py`: đọc dữ liệu, đặc trưng giờ/ngày/cuối tuần, tải NAB.
- `src/eda.py`: biểu đồ trend và seasonality tương tác bằng Plotly.
- `src/models.py`: mô hình, tuning Isolation Forest/LOF, Precision/Recall/F1.
- `backend/api.py`: API JSON.
- `frontend/app.py`: giao diện Streamlit.
